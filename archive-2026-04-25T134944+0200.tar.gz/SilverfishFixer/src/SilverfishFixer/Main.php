<?php

namespace SilverfishFixer;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\server\QueryRegenerateEvent;
use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\block\Block;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    public $config;

    public function onEnable() {
        @mkdir($this->getDataFolder());
        $this->config = new Config($this->getDataFolder() . "config.yml", Config::YAML, ["motd" => "§bHiSmp"]);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    /** @priority HIGHEST */
    public function onQuery(QueryRegenerateEvent $event) {
        $motd = str_replace("&", "§", $this->config->get("motd", "§bHiSmp"));
        // Some Genisys versions use setMotd, some use setServerName
        if(method_exists($event, "setServerName")){
            $event->setServerName($motd);
        } else {
            $event->setMotd($motd);
        }
    }

    public function onEntitySpawn(EntitySpawnEvent $event) {
        $entity = $event->getEntity();
        // Check ID 15 (Silverfish) if the Silverfish class isn't loading
        if ($entity->getNetworkId() === 15) {
            $entity->close();
        }
    }

    public function onBlockBreak(BlockBreakEvent $event) {
        if ($event->getBlock()->getId() === 97) {
            $event->setCancelled();
            $event->getBlock()->getLevel()->setBlock($event->getBlock(), Block::get(1, 0), true, true);
        }
    }

    public function onChunkLoad(ChunkLoadEvent $event) {
        $chunk = $event->getChunk();
        for ($x = 0; $x < 16; $x++) {
            for ($z = 0; $z < 16; $z++) {
                for ($y = 0; $y < 128; $y++) {
                    if ($chunk->getBlockId($x, $y, $z) === 97) {
                        $chunk->setBlockId($x, $y, $z, 1);
                        $chunk->setBlockData($x, $y, $z, 0);
                    }
                }
            }
        }
    }

    public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        if (strtolower($command->getName()) === "mot17") {
            if (!$sender->isOp() || !isset($args[0])) return false;
            $new = implode(" ", $args);
            $this->config->set("motd", $new);
            $this->config->save();
            $sender->sendMessage("§aDone.");
            return true;
        }
        if (strtolower($command->getName()) === "replace" && isset($args[0]) && $args[0] == "1") {
            foreach($this->getServer()->getLevels() as $lvl) {
                foreach($lvl->getChunks() as $c) {
                    for($x=0;$x<16;$x++) for($z=0;$z<16;$z++) for($y=0;$y<128;$y++) {
                        if($c->getBlockId($x,$y,$z) === 97) $lvl->setBlockIdAt(($c->getX()<<4)+$x,$y,($c->getZ()<<4)+$z,1);
                    }
                }
            }
            $sender->sendMessage("§aCleaned.");
            return true;
        }
        return false;
    }
}
